import React from "react";
import { BlockDefinition, PageBlock } from "./types";

// Import all renderers
import { 
  HeroBlock, TrustedByBlock, FeaturesBlock, SuitableForBlock, 
  BentoGridBlock, TestimonialsBlock, FAQBlock, CTABlock, 
  VerticalTabsBlock, HorizontalTabsBlock, ProcessStepsBlock, 
  HeroSecondaryBlock, StatsCounterBlock, FeatureIconGrid, 
  BlogPreviewBlock, CaseStudySliderBlock, CardCarouselBlock, 
  PricingComparisonBlock, RichTextBlock
} from "@/components/sections";

// Import all editors
import { HeroBlockEditor } from "@/components/cms/block-editors/HeroBlockEditor";
import { TrustedByBlockEditor } from "@/components/cms/block-editors/TrustedByBlockEditor";
import { FeaturesBlockEditor } from "@/components/cms/block-editors/FeaturesBlockEditor";
import { SuitableForBlockEditor } from "@/components/cms/block-editors/SuitableForBlockEditor";
import { BentoGridBlockEditor } from "@/components/cms/block-editors/BentoGridBlockEditor";
import { TestimonialsBlockEditor } from "@/components/cms/block-editors/TestimonialsBlockEditor";
import { FAQBlockEditor } from "@/components/cms/block-editors/FAQBlockEditor";
import { CTABlockEditor } from "@/components/cms/block-editors/CTABlockEditor";
import { VerticalTabsBlockEditor } from "@/components/cms/block-editors/VerticalTabsBlockEditor";
import { HorizontalTabsBlockEditor } from "@/components/cms/block-editors/HorizontalTabsBlockEditor";
import { ProcessStepsBlockEditor } from "@/components/cms/block-editors/ProcessStepsBlockEditor";
import { HeroSecondaryBlockEditor } from "@/components/cms/block-editors/HeroSecondaryBlockEditor";
import { StatsCounterBlockEditor } from "@/components/cms/block-editors/StatsCounterBlockEditor";
import { FeatureIconGridEditor } from "@/components/cms/block-editors/FeatureIconGridEditor";
import { BlogPreviewBlockEditor } from "@/components/cms/block-editors/BlogPreviewBlockEditor";
import { CaseStudySliderBlockEditor } from "@/components/cms/block-editors/CaseStudySliderBlockEditor";
import { CardCarouselBlockEditor } from "@/components/cms/block-editors/CardCarouselBlockEditor";
import { PricingComparisonBlockEditor } from "@/components/cms/block-editors/PricingComparisonBlockEditor";
import { RichTextBlockEditor } from "@/components/cms/block-editors/RichTextBlockEditor";

export const MASTER_BLOCK_REGISTRY: BlockDefinition[] = [
  {
    type: "hero",
    label: "🚀 Hero Main",
    description: "Tiêu đề chính, badge, 2 nút bấm và ảnh hero.",
    renderer: HeroBlock,
    editor: HeroBlockEditor,
    defaultData: { badge: "", title: "", highlight: "", subtitle: "", primaryBtn: "Dùng thử miễn phí", secondaryBtn: "Đặt lịch tư vấn", image: "", darkMode: false }
  },
  {
    type: "heroSecondary",
    label: "🖼️ Hero Left Image",
    description: "Ảnh bên trái, nội dung bên phải (Hero phụ).",
    renderer: HeroSecondaryBlock,
    editor: HeroSecondaryBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", description: "", image: "", btnText: "Xem chi tiết", btnUrl: "#", darkMode: false }
  },
  {
    type: "trustedBy",
    label: "🤝 Tin dùng bởi",
    description: "Dải logo đối tác chạy marquee.",
    renderer: TrustedByBlock,
    editor: TrustedByBlockEditor,
    defaultData: { label: "Được tin dùng bởi", highlight: "+20,000 doanh nghiệp", logos: [], darkMode: false }
  },
  {
    type: "features",
    label: "⚡ Tính năng Row",
    description: "Các hàng tính năng xen kẽ với điểm nhấn và stat.",
    renderer: FeaturesBlock,
    editor: FeaturesBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", subtitle: "", items: [{ tag: "", title: "Tính năng mới", points: [""], image: "" }], darkMode: false }
  },
  {
    type: "verticalTabs",
    label: "📂 Vertical Tabs",
    description: "Menu dọc bên trái, nội dung thay đổi bên phải.",
    renderer: VerticalTabsBlock,
    editor: VerticalTabsBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", tabs: [], darkMode: false }
  },
  {
    type: "horizontalTabs",
    label: "📑 Horizontal Tabs",
    description: "Các tab ngang phân loại giải pháp.",
    renderer: HorizontalTabsBlock,
    editor: HorizontalTabsBlockEditor,
    defaultData: { badge: "", title: "", tabs: [], darkMode: false }
  },
  {
    type: "process",
    label: "🛤️ Quy trình",
    description: "Các bước triển khai (1, 2, 3...).",
    renderer: ProcessStepsBlock,
    editor: ProcessStepsBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", steps: [], darkMode: false }
  },
  {
    type: "bentoGrid",
    label: "✨ Bento Grid",
    description: "Lưới 7 tính năng nổi bật (2+1 / 3 / 1+2).",
    renderer: BentoGridBlock,
    editor: BentoGridBlockEditor,
    defaultData: { badge: "Tính năng nổi bật", title: "", titleHighlight: "", subtitle: "", cards: Array(7).fill({ title: "", description: "", image: "" }), darkMode: false }
  },
  {
    type: "featureIconGrid",
    label: "🛠️ Icon Grid",
    description: "Lưới 4 cột icon kèm tính năng kỹ thuật.",
    renderer: FeatureIconGrid,
    editor: FeatureIconGridEditor,
    defaultData: { badge: "", title: "", items: [], darkMode: false }
  },
  {
    type: "stats",
    label: "📊 Số liệu ấn tượng",
    description: "Các con số thống kê nổi bật trên nền tối.",
    renderer: StatsCounterBlock,
    editor: StatsCounterBlockEditor,
    defaultData: { items: [], darkMode: true }
  },
  {
    type: "cardCarousel",
    label: "🎠 Card Slider",
    description: "Dải card tính năng trượt ngang.",
    renderer: CardCarouselBlock,
    editor: CardCarouselBlockEditor,
    defaultData: { badge: "", title: "", subtitle: "", cards: [], darkMode: false }
  },
  {
    type: "testimonials",
    label: "💬 Đánh giá",
    description: "Trích dẫn khách hàng với ảnh đại diện.",
    renderer: TestimonialsBlock,
    editor: TestimonialsBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", items: [{ quote: "", author: "", role: "", avatar: "" }], darkMode: false }
  },
  {
    type: "blogPreview",
    label: "📝 Blog Samples",
    description: "Xem trước các bài viết mới nhất.",
    renderer: BlogPreviewBlock,
    editor: BlogPreviewBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", posts: [], darkMode: false }
  },
  {
    type: "caseStudy",
    label: "🏆 Case Studies",
    description: "Slider dự án thực tế kèm số liệu và quote.",
    renderer: CaseStudySliderBlock,
    editor: CaseStudySliderBlockEditor,
    defaultData: { badge: "", title: "", items: [], darkMode: true }
  },
  {
    type: "suitableFor",
    label: "🎯 Phù hợp với",
    description: "Lưới 3 cột trên nền navy.",
    renderer: SuitableForBlock,
    editor: SuitableForBlockEditor,
    defaultData: { badge: "", title: "", titleHighlight: "", subtitle: "", cards: [{ tag: "", title: "", description: "" }], darkMode: false }
  },
  {
    type: "pricing",
    label: "💰 Bảng giá",
    description: "Bảng so sánh các gói dịch vụ.",
    renderer: PricingComparisonBlock,
    editor: PricingComparisonBlockEditor,
    defaultData: { badge: "", title: "", subtitle: "", plans: [], darkMode: false }
  },
  {
    type: "faq",
    label: "❓ FAQ",
    description: "Câu hỏi thường gặp với accordion.",
    renderer: FAQBlock,
    editor: FAQBlockEditor,
    defaultData: { badge: "Câu hỏi thường gặp", title: "", titleHighlight: "", items: [{ question: "", answer: "" }], darkMode: false }
  },
  {
    type: "cta",
    label: "📋 CTA & Form",
    description: "Nội dung chốt kèm form đăng ký iframe.",
    renderer: CTABlock,
    editor: CTABlockEditor,
    defaultData: { title: "", subtitle: "", bullets: [], formUrl: "", formHeight: 500, darkMode: false }
  },
  {
    type: "richText",
    label: "📝 Rich Text / Blog",
    description: "Nội dung văn bản dài, hỗ trợ Markdown và dán từ Word/WP.",
    renderer: RichTextBlock,
    editor: RichTextBlockEditor,
    defaultData: { content: "", darkMode: false }
  }
];

export function getBlockDefinition(type: string): BlockDefinition | undefined {
  return MASTER_BLOCK_REGISTRY.find(b => b.type === type);
}

export function renderBlockRenderer(block: PageBlock, index: number) {
  const def = getBlockDefinition(block.type);
  if (!def) return null;
  const Renderer = def.renderer;
  return <Renderer key={index} data={block.data} />;
}

export function renderBlockEditor(block: PageBlock, onChange: (data: any) => void) {
  const def = getBlockDefinition(block.type);
  if (!def) return <div className="text-slate-400 text-sm italic">Không tìm thấy editor cho block này ({block.type}).</div>;
  const Editor = def.editor;
  return <Editor data={block.data} onChange={onChange} />;
}

export function getBlockDefaultData(type: string): any {
  const def = getBlockDefinition(type);
  return def ? def.defaultData : { darkMode: false };
}
