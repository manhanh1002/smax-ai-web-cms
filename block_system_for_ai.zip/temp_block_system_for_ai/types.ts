import { ReactNode } from "react";

export type BlockType = string;

export interface BlockDefinition<T = any> {
  type: BlockType;
  label: string;
  description: string;
  icon?: string; // Lucide icon name
  category?: "layout" | "content" | "marketing" | "social";
  
  // Default data for the block when created
  defaultData: T;

  // The component that renders the block on the public site
  renderer: React.ComponentType<{ data: T }>;

  // The component used in the admin panel to edit the block's data
  editor: React.ComponentType<{ data: T; onChange: (data: T) => void }>;
}

export interface PageBlock {
  type: BlockType;
  data: any;
}
