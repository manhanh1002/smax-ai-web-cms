"use client";
import React, { useState } from "react";
import { useActionExecutor } from "@/lib/cms/hooks/use-action-executor";
import type { AnnouncementBarData } from "../definition";

const bgMap: Record<string, string> = {
  violet: "bg-violet-600", blue: "bg-blue-600", emerald: "bg-emerald-600",
  amber: "bg-amber-500", rose: "bg-rose-600", slate: "bg-slate-800",
};

export function AnnouncementBarSaaS({ data }: { data: AnnouncementBarData }) {
  const [dismissed, setDismissed] = useState(false);
  const { executeAction } = useActionExecutor();
  if (dismissed) return null;

  return (
    <div className={`w-full py-2.5 px-4 text-white text-sm ${bgMap[data.bgColor ?? "violet"]}`}>
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-3 relative">
        {data.icon && <span>{data.icon}</span>}
        <span className="font-medium text-center">{data.message}</span>
        {data.ctaText && (
          <button
            onClick={() => executeAction(data.ctaAction)}
            className="flex-shrink-0 underline underline-offset-2 font-semibold hover:opacity-80"
          >
            {data.ctaText} →
          </button>
        )}
        {data.dismissible && (
          <button
            onClick={() => setDismissed(true)}
            className="absolute right-0 top-1/2 -translate-y-1/2 text-white/70 hover:text-white text-xl leading-none"
          >×</button>
        )}
      </div>
    </div>
  );
}
