import type { BlockDefinition, BlockData } from "@/blocks/types";

export interface BeforeAfterData {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  title?: string;
  settings?: any;
}

export const BeforeAfterDef: BlockDefinition<BlockData<BeforeAfterData>> = {
  type: "beforeAfter",
  label: "↔ Before / After",
  description: "Slider so sánh ảnh trước và sau.",
  category: "content",
  defaultData: {
    theme: "saas",
    settings: { paddingTop: "large", paddingBottom: "large", background: "default" },
    beforeImage: "",
    afterImage: "",
    beforeLabel: "Trước",
    afterLabel: "Sau",
  },
};
