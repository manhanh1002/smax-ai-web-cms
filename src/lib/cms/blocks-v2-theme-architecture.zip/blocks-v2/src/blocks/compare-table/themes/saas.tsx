import React from "react";
import { cn } from "@/lib/utils";
import type { CompareTableData } from "../definition";

export function CompareTableSaaS({ data, isDark }: { data: CompareTableData; isDark?: boolean }) {
  const highlight = data.highlightCol ?? 0;
  return (
    <div className="max-w-7xl mx-auto">
      {(data.sectionLabel || data.title) && (
        <div className="text-center mb-12">
          {data.sectionLabel && <p className={cn("text-xs font-bold uppercase tracking-widest mb-3", isDark?"text-violet-400":"text-violet-600")}>{data.sectionLabel}</p>}
          {data.title && <h2 className={cn("text-3xl md:text-4xl font-black", isDark?"text-white":"text-slate-900")}>{data.title}</h2>}
        </div>
      )}
      <div className="overflow-x-auto rounded-2xl border" style={{borderColor: isDark?"rgb(51,65,85)":"rgb(226,232,240)"}}>
        <table className={cn("w-full border-collapse", isDark?"bg-slate-800":"bg-white")}>
          <thead>
            <tr>
              <th className={cn("px-5 py-4 text-left font-bold text-sm border-b", isDark?"border-slate-700 text-white":"border-slate-200 text-slate-900")}>
                Tính năng
              </th>
              {(data.plans??[]).map((plan, i) => (
                <th key={i} className={cn("px-5 py-4 text-center font-bold text-sm border-b whitespace-nowrap", i===highlight?(isDark?"bg-violet-900/30 border-violet-700 text-violet-300":"bg-violet-50 border-violet-200 text-violet-700"):(isDark?"border-slate-700 text-white":"border-slate-200 text-slate-900"))}>
                  {i===highlight && <span className="text-xs mr-1">★</span>}{plan}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(data.categories??[]).map((cat, ci) => (
              <React.Fragment key={ci}>
                <tr>
                  <td colSpan={(data.plans?.length??0)+1} className={cn("px-5 py-3 font-bold text-sm", isDark?"bg-slate-900/50 text-slate-200":"bg-slate-50 text-slate-700")}>
                    {cat.name}
                  </td>
                </tr>
                {(cat.features??[]).map((feat, fi) => (
                  <tr key={fi} className={cn("border-t", isDark?"border-slate-700":"border-slate-100")}>
                    <td className={cn("px-5 py-3 text-sm font-medium", isDark?"text-slate-300":"text-slate-700")}>{feat.label}</td>
                    {(feat.values??[]).map((val, vi) => (
                      <td key={vi} className={cn("px-5 py-3 text-center text-sm", vi===highlight?(isDark?"bg-violet-900/10":"bg-violet-50/60"):"")}>
                        {typeof val === "boolean"
                          ? <span className={val?"text-emerald-500 font-bold":"text-slate-300"}>{val?"✓":"✗"}</span>
                          : <span className={isDark?"text-slate-300":"text-slate-600"}>{val}</span>
                        }
                      </td>
                    ))}
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
