"use client";
import React, { useState } from "react";
import { cn } from "@/lib/utils";
import type { ContactFormData } from "../definition";

export function ContactFormSaaS({ data, isDark }: { data: ContactFormData; isDark?: boolean }) {
  const [formData, setFormData] = useState<Record<string,string>>({});
  const [submitted, setSubmitted] = useState(false);
  const isSplit = data.layout === "side-by-side" && data.contactInfo;
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try { await fetch(data.submitUrl,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(formData)}); } catch {}
    setSubmitted(true); setFormData({}); setTimeout(()=>setSubmitted(false),4000);
  };
  const inputClass = cn("w-full px-4 py-3 rounded-lg border text-sm", isDark?"bg-slate-800 border-slate-700 text-white placeholder-slate-500":"bg-white border-slate-200 text-slate-900 placeholder-slate-400");
  return (
    <div className="max-w-5xl mx-auto">
      <h2 className={cn("text-3xl md:text-4xl font-black mb-3 text-center", isDark?"text-white":"text-slate-900")}>{data.title}</h2>
      {data.subtitle && <p className={cn("text-lg text-center mb-10 max-w-2xl mx-auto", isDark?"text-slate-400":"text-slate-600")}>{data.subtitle}</p>}
      <div className={cn("flex gap-12", isSplit?"flex-col lg:flex-row":"flex-col")}>
        {data.contactInfo && isSplit && (
          <div className="lg:w-1/3 space-y-6">
            {data.contactInfo.address && <div><p className={cn("font-bold mb-1", isDark?"text-white":"text-slate-900")}>📍 Địa chỉ</p><p className={isDark?"text-slate-400":"text-slate-600"}>{data.contactInfo.address}</p></div>}
            {data.contactInfo.phone && <div><p className={cn("font-bold mb-1", isDark?"text-white":"text-slate-900")}>☎️ SĐT</p><a href={`tel:${data.contactInfo.phone}`} className={cn("font-semibold", isDark?"text-violet-400":"text-violet-600")}>{data.contactInfo.phone}</a></div>}
            {data.contactInfo.email && <div><p className={cn("font-bold mb-1", isDark?"text-white":"text-slate-900")}>✉️ Email</p><a href={`mailto:${data.contactInfo.email}`} className={cn("font-semibold", isDark?"text-violet-400":"text-violet-600")}>{data.contactInfo.email}</a></div>}
            {data.contactInfo.hours && <div><p className={cn("font-bold mb-1", isDark?"text-white":"text-slate-900")}>🕐 Giờ</p><p className={isDark?"text-slate-400":"text-slate-600"}>{data.contactInfo.hours}</p></div>}
          </div>
        )}
        <div className={isSplit?"lg:flex-1":"max-w-2xl mx-auto w-full"}>
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              {(data.fields??[]).map(f => (
                <div key={f.name}>
                  <label className={cn("block text-sm font-semibold mb-1.5", isDark?"text-white":"text-slate-900")}>
                    {f.label}{f.required && <span className="text-red-500 ml-1">*</span>}
                  </label>
                  {f.type==="textarea" ? (
                    <textarea name={f.name} placeholder={f.placeholder} required={f.required} rows={4} value={formData[f.name]??""} onChange={e => setFormData(p=>({...p,[f.name]:e.target.value}))} className={inputClass} />
                  ) : f.type==="select" ? (
                    <select name={f.name} required={f.required} value={formData[f.name]??""} onChange={e => setFormData(p=>({...p,[f.name]:e.target.value}))} className={inputClass}>
                      <option value="">Chọn...</option>
                      {(f.options??[]).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                  ) : (
                    <input type={f.type} name={f.name} placeholder={f.placeholder} required={f.required} value={formData[f.name]??""} onChange={e => setFormData(p=>({...p,[f.name]:e.target.value}))} className={inputClass} />
                  )}
                </div>
              ))}
              <button type="submit" className={cn("w-full py-3 rounded-lg font-semibold mt-2", isDark?"bg-violet-600 text-white hover:bg-violet-500":"bg-violet-600 text-white hover:bg-violet-700")}>
                {data.submitText ?? "Gửi"}
              </button>
            </form>
          ) : (
            <div className="py-8 px-6 rounded-lg text-center font-semibold bg-emerald-100 text-emerald-700">✓ Cảm ơn! Chúng tôi sẽ liên hệ sớm.</div>
          )}
        </div>
      </div>
    </div>
  );
}
