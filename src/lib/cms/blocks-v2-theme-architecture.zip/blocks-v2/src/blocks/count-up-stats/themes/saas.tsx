"use client";
import React, { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import type { CountUpStatsData, StatItem } from "../definition";

function StatCard({ stat, isDark, isCards }: { stat: StatItem; isDark?: boolean; isCards: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  const [count, setCount] = useState(0);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setInView(true); }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  useEffect(() => {
    if (!inView) return;
    let cur = 0; const step = stat.value / (1800 / 16);
    const t = setInterval(() => { cur += step; if (cur >= stat.value) { setCount(stat.value); clearInterval(t); } else setCount(Math.floor(cur)); }, 16);
    return () => clearInterval(t);
  }, [inView, stat.value]);
  return (
    <div ref={ref} className={cn("text-center", isCards && (isDark?"bg-slate-800 border border-slate-700 rounded-2xl p-6":"bg-white border border-slate-200 rounded-2xl p-6 shadow-sm"))}>
      {stat.icon && <div className="text-3xl mb-3">{stat.icon}</div>}
      <div className={cn("text-4xl md:text-5xl font-black tabular-nums mb-1", isDark?"text-white":"text-slate-900")}>{stat.prefix}{count.toLocaleString()}{stat.suffix}</div>
      <div className={cn("font-semibold text-base mb-1", isDark?"text-slate-200":"text-slate-800")}>{stat.label}</div>
      {stat.description && <div className={cn("text-sm", isDark?"text-slate-500":"text-slate-400")}>{stat.description}</div>}
    </div>
  );
}

export function CountUpStatsSaaS({ data, isDark }: { data: CountUpStatsData; isDark?: boolean }) {
  const cols = data.columns ?? 3;
  const gridCols: Record<number,string> = { 2:"grid-cols-2", 3:"grid-cols-1 md:grid-cols-3", 4:"grid-cols-2 md:grid-cols-4" };
  const isCards = data.layout === "cards";
  return (
    <div className="max-w-6xl mx-auto">
      {(data.sectionLabel||data.title||data.subtitle) && (
        <div className="text-center mb-12">
          {data.sectionLabel && <p className={cn("text-xs font-bold uppercase tracking-widest mb-3", isDark?"text-violet-400":"text-violet-600")}>{data.sectionLabel}</p>}
          {data.title && <h2 className={cn("text-3xl md:text-4xl font-black mb-3", isDark?"text-white":"text-slate-900")}>{data.title}</h2>}
          {data.subtitle && <p className={cn("text-lg", isDark?"text-slate-400":"text-slate-600")}>{data.subtitle}</p>}
        </div>
      )}
      <div className={cn("grid gap-6", gridCols[cols])}>
        {(data.stats??[]).map((s, i) => <StatCard key={i} stat={s} isDark={isDark} isCards={isCards} />)}
      </div>
    </div>
  );
}
