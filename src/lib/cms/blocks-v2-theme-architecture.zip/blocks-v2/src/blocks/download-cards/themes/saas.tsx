import React from "react";
import { cn } from "@/lib/utils";
import { useActionExecutor } from "@/lib/cms/hooks/use-action-executor";
import type { DownloadCardsData } from "../definition";

const fileIcons: Record<string,string> = { pdf:"📄", doc:"📝", xls:"📊", zip:"📦", video:"🎥" };
const fileColors: Record<string,string> = { pdf:"bg-red-50 text-red-600", doc:"bg-blue-50 text-blue-600", xls:"bg-green-50 text-green-600", zip:"bg-purple-50 text-purple-600", video:"bg-orange-50 text-orange-600" };

export function DownloadCardsSaaS({ data, isDark }: { data: DownloadCardsData; isDark?: boolean }) {
  const { executeAction } = useActionExecutor();
  const gridCols = data.columns===2 ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3";
  return (
    <div className="max-w-6xl mx-auto">
      {(data.sectionLabel||data.title) && (
        <div className="text-center mb-12">
          {data.sectionLabel && <p className={cn("text-xs font-bold uppercase tracking-widest mb-3", isDark?"text-violet-400":"text-violet-600")}>{data.sectionLabel}</p>}
          {data.title && <h2 className={cn("text-3xl md:text-4xl font-black mb-3", isDark?"text-white":"text-slate-900")}>{data.title}</h2>}
          {data.subtitle && <p className={cn("text-lg", isDark?"text-slate-400":"text-slate-600")}>{data.subtitle}</p>}
        </div>
      )}
      <div className={cn("grid gap-6", gridCols)}>
        {(data.resources??[]).map((r, i) => (
          <div key={i} className={cn("rounded-2xl border overflow-hidden hover:border-violet-300 transition-all", isDark?"bg-slate-800 border-slate-700":"bg-white border-slate-200 shadow-sm")}>
            {r.thumbnailUrl && <img src={r.thumbnailUrl} alt={r.title} className="w-full h-48 object-cover" />}
            <div className="p-5">
              <span className={cn("inline-flex items-center gap-2 text-sm font-semibold mb-3 px-3 py-1 rounded-lg", fileColors[r.fileType])}>
                <span className="text-lg">{fileIcons[r.fileType]}</span>{r.fileType.toUpperCase()}
              </span>
              <h3 className={cn("font-bold text-base mb-2", isDark?"text-white":"text-slate-900")}>{r.title}</h3>
              <p className={cn("text-sm mb-4 leading-relaxed", isDark?"text-slate-400":"text-slate-600")}>{r.description}</p>
              <div className={cn("flex items-center justify-between pt-4 border-t", isDark?"border-slate-700":"border-slate-200")}>
                <span className={cn("text-xs font-medium", isDark?"text-slate-400":"text-slate-500")}>{r.fileSize}</span>
                <button onClick={() => executeAction(r.downloadAction)}
                  className={cn("inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-semibold", isDark?"bg-violet-600 text-white hover:bg-violet-500":"bg-violet-600 text-white hover:bg-violet-700")}>
                  Download ↓
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
