"use client";
import React, { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import type { GlossaryData } from "../definition";

export function GlossarySaaS({ data, isDark }: { data: GlossaryData; isDark?: boolean }) {
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState<string|null>(null);
  const [open, setOpen] = useState<number|null>(null);

  const categories = useMemo(() => [...new Set((data.terms??[]).map(t=>t.category).filter(Boolean))] as string[], [data.terms]);
  const filtered = useMemo(() => (data.terms??[]).filter(t => {
    const mS = !search || t.term.toLowerCase().includes(search.toLowerCase()) || t.definition.toLowerCase().includes(search.toLowerCase());
    const mC = !cat || t.category === cat;
    return mS && mC;
  }), [data.terms, search, cat]);

  return (
    <div className="max-w-4xl mx-auto">
      <h2 className={cn("text-3xl md:text-4xl font-black mb-8", isDark?"text-white":"text-slate-900")}>{data.title}</h2>
      {(data.showSearch || data.showFilter) && (
        <div className="space-y-4 mb-8">
          {data.showSearch && (
            <input type="text" placeholder="Tìm kiếm..." value={search} onChange={e => setSearch(e.target.value)}
              className={cn("w-full px-4 py-3 rounded-xl border", isDark?"bg-slate-800 border-slate-700 text-white placeholder-slate-500":"bg-white border-slate-200 text-slate-900 placeholder-slate-400")} />
          )}
          {data.showFilter && categories.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button onClick={() => setCat(null)} className={cn("px-4 py-2 rounded-lg text-sm font-semibold", !cat?"bg-violet-600 text-white":(isDark?"bg-slate-700 text-slate-300":"bg-slate-100 text-slate-700"))}>Tất cả</button>
              {categories.map(c => <button key={c} onClick={() => setCat(c)} className={cn("px-4 py-2 rounded-lg text-sm font-semibold", cat===c?"bg-violet-600 text-white":(isDark?"bg-slate-700 text-slate-300":"bg-slate-100 text-slate-700"))}>{c}</button>)}
            </div>
          )}
        </div>
      )}
      {filtered.length === 0
        ? <div className={cn("text-center py-12", isDark?"text-slate-400":"text-slate-500")}>Không có kết quả</div>
        : <div className="space-y-2">
            {filtered.map((term, i) => {
              const isOpen = open === i;
              return (
                <div key={i} className={cn("border rounded-xl overflow-hidden transition-all", isDark?(isOpen?"bg-slate-800 border-violet-700":"bg-slate-800/50 border-slate-700"):(isOpen?"bg-violet-50 border-violet-200":"bg-white border-slate-200"))}>
                  <button className="w-full flex items-center justify-between gap-3 px-5 py-4 text-left" onClick={() => setOpen(isOpen?null:i)}>
                    <div>
                      <div className={cn("font-bold text-base", isDark?"text-white":"text-slate-900")}>{term.term}</div>
                      {term.category && <div className={cn("text-xs mt-0.5", isDark?"text-slate-400":"text-slate-500")}>{term.category}</div>}
                    </div>
                    <span className={cn("flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold transition-all", isOpen?(isDark?"bg-violet-700 text-white":"bg-violet-600 text-white"):(isDark?"bg-slate-700 text-slate-300":"bg-slate-100 text-slate-600"))}>
                      {isOpen?"−":"+"}
                    </span>
                  </button>
                  {isOpen && (
                    <div className={cn("px-5 pb-4 space-y-3 border-t", isDark?"border-slate-700 text-slate-300":"border-slate-200 text-slate-700")}>
                      <p className="leading-relaxed">{term.definition}</p>
                      {term.example && (
                        <div className={cn("p-3 rounded-lg", isDark?"bg-slate-700/50":"bg-slate-50")}>
                          <div className={cn("text-xs font-semibold mb-1", isDark?"text-slate-400":"text-slate-500")}>Ví dụ:</div>
                          <div className="text-sm italic">{term.example}</div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
      }
    </div>
  );
}
