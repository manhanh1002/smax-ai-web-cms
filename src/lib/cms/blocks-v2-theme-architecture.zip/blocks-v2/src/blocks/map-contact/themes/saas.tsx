import React from "react";
import { cn } from "@/lib/utils";
import type { MapContactData } from "../definition";

export function MapContactSaaS({ data, isDark }: { data: MapContactData; isDark?: boolean }) {
  const isSplit = data.layout !== "full-width";
  return (
    <div className="max-w-6xl mx-auto">
      {data.title && <h2 className={cn("text-3xl md:text-4xl font-black mb-10 text-center", isDark?"text-white":"text-slate-900")}>{data.title}</h2>}
      <div className={cn("flex gap-8", isSplit?(data.layout==="map-right"?"flex-col md:flex-row-reverse":"flex-col md:flex-row"):"flex-col")}>
        <div className={cn("rounded-2xl overflow-hidden", isSplit?"md:flex-1":"w-full")}>
          {data.mapEmbedUrl
            ? <iframe src={data.mapEmbedUrl} width="100%" height="500" style={{border:0}} allowFullScreen loading="lazy" className="w-full h-full min-h-[400px]" />
            : <div className={cn("flex items-center justify-center min-h-[400px] rounded-2xl text-sm", isDark?"bg-slate-800 text-slate-400":"bg-slate-100 text-slate-500")}>Nhập Google Maps Embed URL trong editor</div>
          }
        </div>
        <div className={cn("space-y-6", isSplit?"md:flex-1":"")}>
          {(data.offices??[]).map((office, i) => (
            <div key={i} className={cn("p-6 rounded-xl border", isDark?"bg-slate-800 border-slate-700":"bg-white border-slate-200 shadow-sm")}>
              <h3 className={cn("font-bold text-base mb-4", isDark?"text-white":"text-slate-900")}>{office.name}</h3>
              <div className="space-y-2.5 text-sm">
                {office.address && <div className="flex items-start gap-2"><span className="text-lg mt-0.5">📍</span><span className={isDark?"text-slate-300":"text-slate-700"}>{office.address}</span></div>}
                {office.phone && <div className="flex items-start gap-2"><span className="text-lg mt-0.5">☎️</span><a href={`tel:${office.phone}`} className={cn("font-semibold hover:underline", isDark?"text-violet-400":"text-violet-600")}>{office.phone}</a></div>}
                {office.email && <div className="flex items-start gap-2"><span className="text-lg mt-0.5">✉️</span><a href={`mailto:${office.email}`} className={cn("font-semibold hover:underline", isDark?"text-violet-400":"text-violet-600")}>{office.email}</a></div>}
                {office.hours && <div className="flex items-start gap-2"><span className="text-lg mt-0.5">🕐</span><span className={isDark?"text-slate-300":"text-slate-700"}>{office.hours}</span></div>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
