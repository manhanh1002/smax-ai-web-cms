import React from "react";
import { cn } from "@/lib/utils";
import { useActionExecutor } from "@/lib/cms/hooks/use-action-executor";
import type { MobileAppPreviewData } from "../definition";

export function MobileAppPreviewSaaS({ data, isDark }: { data: MobileAppPreviewData; isDark?: boolean }) {
  const { executeAction } = useActionExecutor();
  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col lg:flex-row gap-12 items-center">
        <div className="flex-1 flex justify-center">
          <div className="relative w-52">
            <div className="bg-black rounded-[2.5rem] p-2 shadow-2xl border-8 border-black">
              {data.mockupImage
                ? <img src={data.mockupImage} alt="App" className="w-full rounded-[1.8rem]" />
                : <div className="w-full aspect-[9/19] rounded-[1.8rem] bg-slate-800 flex items-center justify-center text-slate-500 text-sm">Screenshot</div>
              }
            </div>
          </div>
        </div>
        <div className="flex-1 space-y-6">
          <div>
            <h2 className={cn("text-3xl md:text-4xl font-black mb-3", isDark?"text-white":"text-slate-900")}>{data.title}</h2>
            {data.subtitle && <p className={cn("text-lg", isDark?"text-slate-400":"text-slate-600")}>{data.subtitle}</p>}
          </div>
          {(data.appStoreAction || data.playStoreAction) && (
            <div className="flex flex-wrap gap-3">
              {data.appStoreText && (
                <button onClick={() => executeAction(data.appStoreAction)}
                  className={cn("px-5 py-2.5 rounded-xl font-semibold text-sm border transition-colors", isDark?"bg-slate-800 text-white border-slate-700 hover:bg-slate-700":"bg-slate-900 text-white border-slate-900 hover:bg-slate-700")}>
                  🍎 {data.appStoreText}
                </button>
              )}
              {data.playStoreText && (
                <button onClick={() => executeAction(data.playStoreAction)}
                  className={cn("px-5 py-2.5 rounded-xl font-semibold text-sm border transition-colors", isDark?"bg-slate-800 text-white border-slate-700 hover:bg-slate-700":"bg-slate-900 text-white border-slate-900 hover:bg-slate-700")}>
                  🤖 {data.playStoreText}
                </button>
              )}
            </div>
          )}
          {(data.features ?? []).length > 0 && (
            <ul className="space-y-2.5">
              {data.features.map((f, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className={cn("mt-0.5 text-lg", isDark?"text-violet-400":"text-violet-600")}>✓</span>
                  <span className={cn("text-base", isDark?"text-slate-300":"text-slate-700")}>{f}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
