"use client";
import React, { useState } from "react";
import { cn } from "@/lib/utils";
import type { NewsletterSignupData } from "../definition";

export function NewsletterSignupSaaS({ data, isDark }: { data: NewsletterSignupData; isDark?: boolean }) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const bgStyle = data.bgStyle ?? "light";
  const isGrad = bgStyle === "gradient";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    try { await fetch(data.submitUrl, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ email }) }); } catch {}
    setDone(true); setEmail(""); setTimeout(() => setDone(false), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto text-center">
      <h2 className={cn("text-3xl md:text-4xl font-black mb-3", isDark||isGrad ? "text-white" : "text-slate-900")}>{data.title}</h2>
      {data.subtitle && <p className={cn("text-lg mb-8", isDark||isGrad ? "text-white/80" : "text-slate-600")}>{data.subtitle}</p>}
      {!done ? (
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex gap-2">
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
              placeholder={data.placeholder ?? "Nhập email của bạn..."}
              className={cn("flex-1 px-4 py-3 rounded-xl border", isDark||isGrad
                ? "bg-white/10 border-white/20 text-white placeholder-white/50"
                : "bg-white border-slate-300 text-slate-900 placeholder-slate-400")} />
            <button type="submit" className={cn("px-6 py-3 rounded-xl font-semibold whitespace-nowrap", isGrad||isDark ? "bg-white text-violet-600" : "bg-violet-600 text-white hover:bg-violet-700")}>
              {data.submitText ?? "Đăng ký"}
            </button>
          </div>
          {data.subscriberCount && <p className={cn("text-sm", isDark||isGrad ? "text-white/70" : "text-slate-500")}>✓ {data.subscriberCount}</p>}
        </form>
      ) : (
        <div className="py-4 px-6 rounded-xl bg-emerald-100 text-emerald-700 font-semibold">✓ Cảm ơn! Kiểm tra email của bạn.</div>
      )}
    </div>
  );
}
