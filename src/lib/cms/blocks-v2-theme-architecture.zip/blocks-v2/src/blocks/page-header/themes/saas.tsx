import React from "react";
import { cn } from "@/lib/utils";
import { useActionExecutor } from "@/lib/cms/hooks/use-action-executor";
import type { PageHeaderData } from "../definition";

export function PageHeaderSaaS({ data, isDark }: { data: PageHeaderData; isDark?: boolean }) {
  const { executeAction } = useActionExecutor();
  const isCenter = data.alignment === "center";
  return (
    <div className={cn("border-b max-w-4xl mx-auto space-y-4 pb-8", isDark?"border-slate-700":"border-slate-200", isCenter&&"text-center")}>
      {(data.breadcrumbs ?? []).length > 0 && (
        <nav className="flex items-center gap-1.5 text-sm flex-wrap" aria-label="Breadcrumb">
          {data.breadcrumbs!.map((crumb, i) => (
            <React.Fragment key={i}>
              {i > 0 && <span className={isDark?"text-slate-500":"text-slate-400"}>/</span>}
              {crumb.action
                ? <button onClick={() => executeAction(crumb.action)} className={cn("hover:underline", isDark?"text-slate-400 hover:text-white":"text-slate-500 hover:text-slate-900")}>{crumb.label}</button>
                : <span className={isDark?"text-slate-200":"text-slate-700"}>{crumb.label}</span>
              }
            </React.Fragment>
          ))}
        </nav>
      )}
      {(data.tags ?? []).length > 0 && (
        <div className={cn("flex gap-2 flex-wrap", isCenter&&"justify-center")}>
          {data.tags!.map((tag, i) => <span key={i} className={cn("text-xs font-semibold px-3 py-1 rounded-full", isDark?"bg-violet-900/40 text-violet-300":"bg-violet-100 text-violet-700")}>{tag}</span>)}
        </div>
      )}
      <h1 className={cn("text-3xl md:text-5xl font-black leading-tight", isDark?"text-white":"text-slate-900")}>{data.title}</h1>
      {data.subtitle && <p className={cn("text-lg leading-relaxed max-w-2xl", isCenter&&"mx-auto", isDark?"text-slate-300":"text-slate-600")}>{data.subtitle}</p>}
      {(data.authorName || data.publishDate || data.readTime) && (
        <div className={cn("flex items-center gap-3 text-sm flex-wrap", isCenter&&"justify-center")}>
          {data.authorAvatar && <img src={data.authorAvatar} alt={data.authorName} className="w-8 h-8 rounded-full object-cover" />}
          {data.authorName && <span className={cn("font-medium", isDark?"text-slate-200":"text-slate-800")}>{data.authorName}</span>}
          {data.publishDate && <span className={isDark?"text-slate-400":"text-slate-500"}>· {data.publishDate}</span>}
          {data.readTime   && <span className={isDark?"text-slate-400":"text-slate-500"}>· {data.readTime}</span>}
        </div>
      )}
    </div>
  );
}
