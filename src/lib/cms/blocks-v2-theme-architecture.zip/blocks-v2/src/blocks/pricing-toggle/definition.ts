import type { BlockDefinition, BlockData } from "@/blocks/types";
export interface PricingPlan { name: string; monthlyPrice: number; annualPrice: number; currency: string; description?: string; features: string[]; ctaText: string; ctaAction?: any; popular?: boolean; badge?: string; }
export interface PricingToggleData { sectionLabel?: string; title: string; subtitle?: string; plans: PricingPlan[]; savingsBadge?: string; settings?: any; }
export const PricingToggleDef: BlockDefinition<BlockData<PricingToggleData>> = {
  type:"pricingToggle", label:"💰 Pricing Toggle", description:"Bảng giá với toggle tháng/năm.", category:"marketing",
  defaultData:{ theme:"saas", settings:{paddingTop:"large",paddingBottom:"large",background:"default"}, title:"Bảng giá", plans:[], savingsBadge:"Tiết kiệm 20%" },
};
