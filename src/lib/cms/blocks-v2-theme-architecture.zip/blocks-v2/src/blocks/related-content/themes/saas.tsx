import React from "react";
import { cn } from "@/lib/utils";
import { useActionExecutor } from "@/lib/cms/hooks/use-action-executor";
import type { RelatedContentData } from "../definition";

const typeLabels: Record<string,string> = { blog:"Blog","case-study":"Case Study",video:"Video",resource:"Resource" };
const typeColors: Record<string,string> = { blog:"bg-blue-100 text-blue-700","case-study":"bg-green-100 text-green-700",video:"bg-red-100 text-red-700",resource:"bg-purple-100 text-purple-700" };

export function RelatedContentSaaS({ data, isDark }: { data: RelatedContentData; isDark?: boolean }) {
  const { executeAction } = useActionExecutor();
  const gridCols = data.columns===2 ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3";
  return (
    <div className="max-w-6xl mx-auto">
      {data.title && <h2 className={cn("text-3xl md:text-4xl font-black mb-10 text-center", isDark?"text-white":"text-slate-900")}>{data.title}</h2>}
      <div className={cn("grid gap-6", gridCols)}>
        {(data.items??[]).map((item, i) => (
          <button key={i} onClick={() => executeAction(item.action)}
            className={cn("rounded-2xl border overflow-hidden hover:border-violet-300 hover:-translate-y-1 transition-all group text-left w-full", isDark?"bg-slate-800 border-slate-700":"bg-white border-slate-200 shadow-sm")}>
            <div className="relative h-40 overflow-hidden bg-slate-200">
              {item.thumbnail && <img src={item.thumbnail} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />}
            </div>
            <div className="p-5">
              {data.showType && <span className={cn("inline-block text-xs font-bold px-2.5 py-1 rounded-full mb-3", typeColors[item.type])}>{typeLabels[item.type]}</span>}
              <h3 className={cn("font-bold text-base mb-2 line-clamp-2 group-hover:text-violet-600 transition-colors", isDark?"text-white":"text-slate-900")}>{item.title}</h3>
              {item.excerpt && <p className={cn("text-sm mb-3 line-clamp-2", isDark?"text-slate-400":"text-slate-600")}>{item.excerpt}</p>}
              <div className={cn("flex items-center justify-between pt-3 border-t", isDark?"border-slate-700":"border-slate-200")}>
                {data.showDate && item.date && <span className={cn("text-xs", isDark?"text-slate-500":"text-slate-400")}>{item.date}</span>}
                {item.tag && <span className={cn("text-xs font-semibold px-2 py-1 rounded", isDark?"bg-slate-700 text-slate-300":"bg-slate-100 text-slate-700")}>{item.tag}</span>}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
