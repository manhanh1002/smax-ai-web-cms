"use client";
import React, { useState } from "react";
import { cn } from "@/lib/utils";
import type { VideoSectionData } from "../definition";

function getEmbed(url: string) {
  const yt = url.match(/(?:youtu\.be\/|watch\?v=|embed\/)([^#&?]{11})/);
  if (yt) return `https://www.youtube.com/embed/${yt[1]}?autoplay=1&rel=0`;
  const vm = url.match(/vimeo\.com\/(\d+)/);
  if (vm) return `https://player.vimeo.com/video/${vm[1]}?autoplay=1`;
  return url;
}

export function VideoSectionSaaS({ data, isDark }: { data: VideoSectionData; isDark?: boolean }) {
  const [playing, setPlaying] = useState(false);
  const isSplit = data.layout === "split";
  const embedUrl = getEmbed(data.videoUrl);

  const VideoBox = (
    <div className={cn("relative rounded-2xl overflow-hidden bg-black", isSplit ? "flex-1" : "w-full max-w-3xl mx-auto")} style={{aspectRatio:"16/9"}}>
      {playing ? (
        <iframe src={embedUrl} className="w-full h-full" frameBorder="0" allow="autoplay;fullscreen" allowFullScreen />
      ) : (
        <>
          {data.thumbnailUrl && <img src={data.thumbnailUrl} alt={data.title} className="absolute inset-0 w-full h-full object-cover" />}
          <button onClick={() => setPlaying(true)} className="absolute inset-0 flex items-center justify-center bg-black/40 hover:bg-black/50 transition-all">
            <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur flex items-center justify-center hover:bg-white/30 transition-all">
              <div className="w-0 h-0 ml-1" style={{borderLeft:"28px solid white",borderTop:"16px solid transparent",borderBottom:"16px solid transparent"}} />
            </div>
          </button>
        </>
      )}
    </div>
  );

  const TextBox = (data.title || data.description) ? (
    <div className={isSplit ? "flex-1" : "mt-6 text-center"}>
      <h2 className={cn("text-2xl md:text-3xl font-black mb-3", isDark?"text-white":"text-slate-900")}>{data.title}</h2>
      {data.description && <p className={cn("text-base leading-relaxed", isDark?"text-slate-400":"text-slate-600")}>{data.description}</p>}
    </div>
  ) : null;

  return (
    <div className="max-w-5xl mx-auto">
      <div className={cn("flex gap-8 items-center", isSplit ? "flex-col md:flex-row" : "flex-col")}>
        {VideoBox}
        {TextBox}
      </div>
    </div>
  );
}
